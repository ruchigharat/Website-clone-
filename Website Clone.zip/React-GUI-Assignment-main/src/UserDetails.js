let users = [
    {
      userimg: "img/cover 1.png",
      username: "HackerisAlive",
      userpost: "img/cover 1.png"
    },
    {
      userimg: "img/cover 2.png",
      username: "HackerisAlive",
      userpost: "img/cover 2.png"
    },
    {
      userimg: "img/cover 3.png",
      username: "HackerisAlive",
      userpost: "img/cover 3.png"
    },
    {
      userimg: "img/cover 4.png",
      username: "HackerisAlive",
      userpost: "img/cover 4.png"
    },
    {
      userimg: "img/cover 5.png",
      username: "HackerisAlive",
      userpost: "img/cover 5.png"
    },
    {
      userimg: "img/cover 6.png",
      username: "HackerisAlive",
      userpost: "img/cover 6.png"
    },
    {
      userimg: "img/cover 7.png",
      username: "HackerisAlive",
      userpost: "img/cover 7.png"
    }
  ];
  
  export default users;
  